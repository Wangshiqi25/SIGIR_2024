## Prerequisites

The code is written in [TensorFlow](https://www.tensorflow.org/) library. To use the program the following prerequisites need to be installed.

- Python 3.5.2
- tensorflow-gpu==1.12.0
- numpy ==1.15.4
- regex==2.4.120

## Quick Start

- Pretrained model

  The approach to downloading the pretrained model can be found [here](https://github.com/openai/gpt-2). We adopted the small-version with 124M parameter.

- Parameter setting

  ```
  --is_train		Set to 1/0 to train/inference.
  --cond			Set to 1/0 to generate stories unconditionally/conditionally on the beginning.
  --model_dir		Model directory.
  --gpu			Specify which gpu to use. (default 0)
  --batch_size		Number of batches (only affects speed/memory, default 10)
  --data_name		Set `roc` to train the model on ROCStories corpus or \
  				`kg` to train the model on the knowledge bases or \
  				`multi_roc` to train the model on ROCStories with multi-task learning.
  --n_class		Number of classes for the auxiliary classification task. (default 4)
  --learning_rate		Learning rate. (default 1e-4)
  --data_dir		Data directory.
  --length		Number of tokens in generated text. (default 200)
  --temperature		Float value controlling randomness in boltzmann distribution. Lower temperature results in less random completions. As the temperature approaches zero, the model will become deterministic and repetitive. Higher temperature results in more random completions. (default 0.7)
  --top_k			Integer value controlling diversity. (default 40)
  ```

- Training

  The pretrained model can be post-trained on the knowledge bases by executing the following command:

  ​	`python3 main.py --is_train 1 --data_name kg `

