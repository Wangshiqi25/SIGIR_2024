## Loss Functions

### Encoder Loss


- VAE Loss: Variational-Autoencoder Loss which has KL-Divergence and Cross-Entropy. KLD annealing is used to avoid the loss from KLD to drop zero once the training begins.

### Generator Loss

- VAE Loss


- Reconstruction of z: The generated sentence is sent back to encoder and loss from reconstruction of z is added to the generator loss. To pass the gradient back to generator, soft distribution is used as the input.

- Reconstruction of c: The generated sentence is used as input to verifier. Again we use soft distribution as the input. 

### Verifier Loss (semi-supervised learning with signal from generated data)


- Loss from labelled data: Here X<sub>L</sub> are the sentences and C<sub>L</sub> are the corresponding labels.

- Loss from generated data: In the sleep phase, sentences are generated for random `z` and `c`. Discriminator uses that `c` as the signal for the generated data. An additional entropy regularizing term is used to alleviate the issue of noisy data from generator.
