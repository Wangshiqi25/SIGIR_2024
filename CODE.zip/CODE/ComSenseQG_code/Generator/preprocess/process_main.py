# coding=utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import sys

sys.path.append(".")
from utils.config_utils import dict_to_args
from utils.config_utils import yaml_load_dict
from preprocess.nmt_process import make_nmt_dataset
from preprocess.nmt_process import make_nmt_simple_dataset
from struct_self.generate_dataset import make_dataset


def cosmos_preprocess():
    config_file = "/home/user_data/yjx/projects/cosmos/configs/data_configs/cosmos.yaml"
    args_dict = yaml_load_dict(config_file)
    args = dict_to_args(args_dict)
    make_nmt_dataset(
        train_file=args.train_file,
        dev_file=args.dev_file,
        test_file=args.test_file,
        tgt_dir=args.origin_tgts,
    )


def cosmos_construction():
    config_file = "/home/user_data/yjx/projects/cosmos/configs/data_configs/cosmos.yaml"
    args_dict = yaml_load_dict(config_file)
    args = dict_to_args(args_dict)
    data_dir = args.origin_tgts
    data_dict = {
        "train": "train.s2b",
        "dev": "dev.s2b",
        "test": "test.s2b",
    }
    make_dataset(
        data_dir=data_dir,
        data_dict=data_dict,
        tgt_dir=data_dir,
        max_src_vocab=args.max_src_vocab,
        max_tgt_vocab=args.max_tgt_vocab,
        vocab_freq_cutoff=args.cut_off,
        max_src_length=-1,
        max_tgt_length=-1,
    )
    make_dataset(
        data_dir=data_dir,
        data_dict=data_dict,
        tgt_dir=args.sample_tgts,
        max_src_vocab=args.max_src_vocab,
        max_tgt_vocab=args.max_tgt_vocab,
        vocab_freq_cutoff=args.cut_off,
        max_src_length=args.max_src_length,
        max_tgt_length=args.max_tgt_length,
    )


def mcscript_preprocess():
    config_file = "/home/user_data/yjx/projects/cosmos/configs/data_configs/mcscript.yaml"
    args_dict = yaml_load_dict(config_file)
    args = dict_to_args(args_dict)
    make_nmt_simple_dataset(
        train_file=args.train_file,
        dev_file=args.dev_file,
        test_file=args.test_file,
        tgt_dir=args.origin_tgts,
    )


def mcscript_construction():
    config_file = "/home/user_data/yjx/projects/cosmos/configs/data_configs/mcscript.yaml"
    args_dict = yaml_load_dict(config_file)
    args = dict_to_args(args_dict)
    data_dir = args.origin_tgts
    data_dict = {
        "train": "train.s2b",
        "dev": "dev.s2b",
        "test": "test.s2b",
    }
    make_dataset(
        data_dir=data_dir,
        data_dict=data_dict,
        tgt_dir=data_dir,
        max_src_vocab=args.max_src_vocab,
        max_tgt_vocab=args.max_tgt_vocab,
        vocab_freq_cutoff=args.cut_off,
        max_src_length=-1,
        max_tgt_length=-1,
    )


if __name__ == '__main__':
    # nmt_construction()
    # mt_construction()
    # webnlg_preprocess()
    # webnlg_construction()
    # webnlg_robust_construction()
    # s2b_construction(False)
    # snli_process_construction(False)
    # snli_sample_construction(False)
    config_file = "/home/user_data/yjx/projects/cosmos/configs/data_configs/cosmos.yaml"
    quora_construction(config_file=config_file, is_write=True)
